NEXORA ADVANCED — Clinical Trial Eligibility Matcher
ZERO-TERMINAL WINDOWS START
1. Extract the ZIP.
2. Install Python 3.10+ once (select “Add Python to PATH”).
3. Double-click START_NEXORA.bat. It installs Flask, starts the local backend, and opens the site.
4. If the browser opens too early, wait a few seconds and refresh http://127.0.0.1:5000.
5. Choose a fictional protocol, fill synthetic patient data, tick evidence documents, and run the matcher.

FEATURES
• Flask REST backend: /api/catalog, /api/match, /api/audit
• 45+ disease categories in the diagnosis catalogue; five fictional protocol examples across oncology, metabolic, cardiac and autoimmune research
• Configurable protocol criteria: age, diagnosis, ECOG, creatinine, required evidence and note-based potential exclusion flags
• Explainable criterion-by-criterion result, missing evidence, mismatch flags and completeness indicator
• Downloadable JSON review report, print view, local audit trail, responsive interface
• Synthetic demo patient and no external data transmission; backend binds only to localhost

IMPORTANT LIMITATION
“all diseases tested” cannot be safely claimed: the catalogue includes broad disease categories, but only five fictional protocols have matching criteria. Every real trial has unique protocol-specific criteria, labs, biomarkers, timing, and exclusions. Add verified protocol criteria before evaluating a disease. This is not a diagnostic model, medical advice, validated eligibility decision, or enrollment tool. Never use real identifiable health data. A qualified clinical/research team must verify every rule and source document. The completeness percentage is not an enrollment probability.
