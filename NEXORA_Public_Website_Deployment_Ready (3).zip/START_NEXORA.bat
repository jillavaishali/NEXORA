@echo off
setlocal
cd /d "%~dp0"

echo Starting NEXORA...
where py >nul 2>nul
if errorlevel 1 (
  echo.
  echo Python is not installed or the Python launcher is unavailable.
  echo Please install Python 3.10+ and select "Add Python to PATH".
  pause
  exit /b 1
)

if not exist "%~dp0app.py" (
  echo ERROR: app.py was not found in this folder.
  pause
  exit /b 1
)

if not exist "%~dp0requirements.txt" (
  echo Flask>=3.0,<4.0>"%~dp0requirements.txt"
)

echo Installing/checking Flask...
py -m pip install -r "%~dp0requirements.txt"
if errorlevel 1 (
  echo.
  echo Flask installation failed. Please check your internet connection.
  pause
  exit /b 1
)

echo Opening NEXORA in your browser...
start "" "http://127.0.0.1:5000"

echo Starting NEXORA server...
py "%~dp0app.py"
pause
