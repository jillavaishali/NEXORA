from flask import Flask, request, jsonify, send_from_directory
from datetime import datetime, timezone
import json, os, re
app=Flask(__name__, static_folder="static")
DB=os.path.join(os.path.dirname(__file__),"demo_audit.json")
DISEASES=[
"Breast cancer","Lung cancer (NSCLC)","Lung cancer (SCLC)","Colorectal cancer","Prostate cancer","Ovarian cancer","Cervical cancer","Leukemia","Lymphoma","Multiple myeloma","Pancreatic cancer","Liver cancer","Melanoma","Brain tumor / glioma","Head and neck cancer",
"Type 1 diabetes","Type 2 diabetes","Hypertension","Heart failure","Coronary artery disease","Chronic kidney disease","Asthma","COPD","Tuberculosis","HIV","Hepatitis B","Hepatitis C","Rheumatoid arthritis","Lupus","Multiple sclerosis","Alzheimer's disease","Parkinson's disease","Epilepsy","Depression","Anxiety disorder","Obesity","Anemia","Sickle cell disease","Osteoporosis","Inflammatory bowel disease","Crohn's disease","Ulcerative colitis","Psoriasis","Endometriosis","Migraine","Stroke recovery","Other / custom"
]
TRIALS=[
{"id":"NX-ONC-01","name":"Precision Oncology Demonstration","disease":"Breast cancer","min_age":18,"max_age":75,"max_ecog":1,"max_creatinine":1.5,"requires":["pathology report","recent CBC","renal panel"],"excludes":["active infection","pregnancy"],"phase":"II","source":"Fictional demo protocol v1.0"},
{"id":"NX-ONC-02","name":"Thoracic Oncology Demonstration","disease":"Lung cancer (NSCLC)","min_age":18,"max_age":80,"max_ecog":2,"max_creatinine":1.8,"requires":["histology report","recent CBC","renal panel","recent imaging"],"excludes":["active infection"],"phase":"III","source":"Fictional demo protocol v1.0"},
{"id":"NX-MET-01","name":"Metabolic Health Demonstration","disease":"Type 2 diabetes","min_age":18,"max_age":70,"max_ecog":2,"max_creatinine":2.0,"requires":["HbA1c","renal panel","medication history"],"excludes":["pregnancy"],"phase":"II","source":"Fictional demo protocol v1.0"},
{"id":"NX-CARD-01","name":"Cardio-Renal Observational Demonstration","disease":"Heart failure","min_age":21,"max_age":85,"max_ecog":3,"max_creatinine":2.5,"requires":["echocardiogram","renal panel","medication history"],"excludes":["active infection"],"phase":"Observational","source":"Fictional demo protocol v1.0"},
{"id":"NX-IMM-01","name":"Autoimmune Research Demonstration","disease":"Rheumatoid arthritis","min_age":18,"max_age":75,"max_ecog":2,"max_creatinine":1.8,"requires":["rheumatology assessment","CBC","medication history"],"excludes":["active infection","pregnancy"],"phase":"II","source":"Fictional demo protocol v1.0"}
]
@app.get("/")
def home(): return send_from_directory("static","index.html")
@app.get("/api/catalog")
def catalog(): return jsonify({"diseases":DISEASES,"trials":TRIALS,"notice":"Fictional educational demo; not clinically validated."})
@app.post("/api/match")
def match():
 p=request.get_json(force=True); t=next((x for x in TRIALS if x["id"]==p.get("trial_id")),None)
 if not t:return jsonify({"error":"Unknown demo trial"}),400
 try: age=int(p.get("age")); ecog=int(p.get("ecog")); cr=float(p.get("creatinine"))
 except (TypeError,ValueError):return jsonify({"error":"Enter valid age, ECOG and creatinine values."}),400
 if not 1<=age<=120 or ecog not in range(5) or cr<=0:return jsonify({"error":"Values are outside demo validation bounds."}),400
 notes=(p.get("notes") or "").lower(); evidence=[x.lower().strip() for x in p.get("evidence",[])]; inc=[]; exc=[]; missing=[]
 def check(ok,yes,no): (inc if ok else exc).append(yes if ok else no)
 check(p.get("disease")==t["disease"],"Diagnosis matches the demo protocol.","Diagnosis does not match the demo protocol disease.")
 check(t["min_age"]<=age<=t["max_age"],f"Age {age} is within {t['min_age']}–{t['max_age']}.",f"Age {age} is outside {t['min_age']}–{t['max_age']}.")
 check(ecog<=t["max_ecog"],f"ECOG {ecog} is within the demo limit.",f"ECOG {ecog} exceeds the demo limit.")
 check(cr<=t["max_creatinine"],f"Creatinine {cr:g} mg/dL is within the demo threshold.",f"Creatinine {cr:g} mg/dL exceeds the demo threshold.")
 for req in t["requires"]:
  if any(req.lower() in e or e in req.lower() for e in evidence):inc.append(f"Evidence recorded: {req}.")
  else:missing.append(f"Missing evidence: {req}.")
 for term in t["excludes"]:
  if term in notes:exc.append(f"Potential exclusion flag found in notes: {term}; human review required.")
 score=max(0,round(100*len(inc)/(len(inc)+len(exc)+len(missing) or 1)))
 status="Needs human review" if missing or exc else "No demo flags found — verify"
 result={"timestamp":datetime.now(timezone.utc).isoformat(),"trial":t,"patient_label":p.get("patient_label","Demo patient"),"status":status,"score":score,"criteria_checked":4+len(t["requires"])+len(t["excludes"]),"included":inc,"flags":exc,"missing":missing,"explanation":"Transparent rule-based comparison against fictional criteria. Score is a completeness indicator, not probability of enrollment or clinical suitability."}
 try:
  logs=json.load(open(DB)) if os.path.exists(DB) else []
  logs.append({"timestamp":result["timestamp"],"patient_label":result["patient_label"],"trial_id":t["id"],"status":status,"score":score})
  json.dump(logs[-500:],open(DB,"w"),indent=2)
 except Exception:pass
 return jsonify(result)
@app.get("/api/audit")
def audit():
 try:return jsonify(json.load(open(DB))[-100:])
 except:return jsonify([])
if __name__=="__main__": app.run(host="127.0.0.1",port=5000,debug=False)
