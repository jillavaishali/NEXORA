Set WshShell = CreateObject("WScript.Shell")
WshShell.Run Chr(34) & WshShell.CurrentDirectory & "\START_NEXORA.bat" & Chr(34), 0, False
